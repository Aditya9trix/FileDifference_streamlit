from docx import Document
import pdfplumber
import pandas as pd
from PIL import Image
import cv2
import numpy as np
from io import BytesIO
import fitz
import streamlit as st

class FileHandler:
    def __init__(self):
        pass

    def extract_content(self, file):
        content = []
        if file.type == "application/vnd.openxmlformats-officedocument.wordprocessingml.document":
            content = self._extract_from_docx(file)
        elif file.type == "application/pdf":
            content = self._extract_from_pdf(file)
        elif file.type == "text/plain":
            content = self._extract_from_txt(file)
        return content

    def _extract_from_docx(self, file):
        content = []
        try:
            doc = Document(file)
            content_id = 0
            table_index = 0

            image_dict = {}
            for rel in doc.part.rels:
                if "image" in doc.part.rels[rel].target_ref:
                    image_data = doc.part.rels[rel].target_part.blob
                    img = Image.open(BytesIO(image_data)).convert('RGB')
                    img_cv = cv2.cvtColor(np.array(img), cv2.COLOR_RGB2BGR)
                    image_dict[rel] = img_cv

            for element in doc.element.body:
                if element.tag.endswith('p'):
                    text = element.text.strip()
                    if text:
                        content.append({"type": "text", "content": text, "id": f"content_{content_id}"})
                        content_id += 1

                    for run in element.xpath('.//w:r'):
                        drawing = run.xpath('.//w:drawing')
                        if drawing:
                            blip = drawing[0].xpath('.//a:blip/@r:embed')
                            if blip:
                                rel_id = blip[0]
                                if rel_id in image_dict:
                                    content.append(
                                        {"type": "image", "content": image_dict[rel_id], "id": f"content_{content_id}"})
                                    content_id += 1

                elif element.tag.endswith('tbl'):
                    if table_index < len(doc.tables):
                        table = doc.tables[table_index]
                        data = [[cell.text.strip() for cell in row.cells] for row in table.rows]
                        content.append({"type": "table", "content": pd.DataFrame(data), "id": f"content_{content_id}"})
                        content_id += 1
                        table_index += 1

        except Exception as e:
            st.error(f"Error extracting content from DOCX: {e}")
        return content

    def _extract_from_pdf(self, file):
        content = []
        try:
            with pdfplumber.open(file) as pdf:
                content_id = 0

                for page in pdf.pages:
                    text = page.extract_text()
                    if text:
                        content.append({"type": "text", "content": text, "id": f"content_{content_id}"})
                        content_id += 1

                    tables = page.extract_tables()
                    for table in tables:
                        content.append({"type": "table", "content": pd.DataFrame(table), "id": f"content_{content_id}"})
                        content_id += 1

            pdf_doc = fitz.open(stream=file.read(), filetype="pdf")
            for page in pdf_doc:
                for img_info in page.get_images(full=True):
                    xref = img_info[0]
                    base_image = pdf_doc.extract_image(xref)
                    img_pil = Image.open(BytesIO(base_image["image"])).convert("RGB")
                    img_cv = cv2.cvtColor(np.array(img_pil), cv2.COLOR_RGB2BGR)
                    content.append({"type": "image", "content": img_cv, "id": f"content_{content_id}"})
                    content_id += 1

        except Exception as e:
            st.error(f"Error extracting content from PDF: {e}")
        return content

    def _extract_from_txt(self, file):
        content = []
        text = file.read().decode("utf-8")
        paragraphs = [p.strip() for p in text.split("\n\n") if p.strip()]
        for para in paragraphs:
            content.append({"type": "text", "content": para, "id": f"content_{len(content)}"})
        return content