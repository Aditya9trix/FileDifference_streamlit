import cv2
from skimage.metrics import structural_similarity as ssim
import streamlit as st
class ImageProcessor:
    @staticmethod
    def compare_images(img1, img2):
        try:
            img2_resized = cv2.resize(img2, (img1.shape[1], img1.shape[0]))
            similarity_index, _ = ssim(
                cv2.cvtColor(img1, cv2.COLOR_BGR2GRAY),
                cv2.cvtColor(img2_resized, cv2.COLOR_BGR2GRAY),
                full=True,
                win_size=min(7, min(img1.shape[0], img1.shape[1]) - 1)
            )
            return similarity_index
        except Exception as e:
            st.warning(f"Image comparison failed: {str(e)}")
            return 0

    @staticmethod
    def add_border(image, color, thickness=10):
        return cv2.copyMakeBorder(image, thickness, thickness, thickness, thickness, cv2.BORDER_CONSTANT, value=color)

    @staticmethod
    def compare_image_lists(master_images, sample_images):
        missing_images = []
        new_images = []
        moved_images = []

        # Create mappings between image content and their positions
        master_positions = {}
        sample_positions = {}

        # First pass: find all matching images
        matches = []
        for i, master_img in enumerate(master_images):
            for j, sample_img in enumerate(sample_images):
                similarity = ImageProcessor.compare_images(master_img["content"], sample_img["content"])
                if similarity >= 0.8:  # Threshold for considering images as matching
                    matches.append((i, j, similarity))
                    master_positions[i] = master_img["id"]
                    sample_positions[j] = sample_img["id"]

        # Second pass: identify position changes
        # We'll consider an image moved if:
        # 1. It exists in both files
        # 2. Its relative position has changed significantly
        # (more than 1 position difference in either direction)

        # Build a mapping of which master images match which sample images
        master_to_sample = {}
        sample_to_master = {}
        for i, j, _ in matches:
            master_to_sample[i] = j
            sample_to_master[j] = i

        # Check for position changes
        for i, j, _ in matches:
            master_img_id = master_images[i]["id"]
            sample_img_id = sample_images[j]["id"]

            # Get the relative positions (what percentage through the document they appear)
            master_pos = i / len(master_images)
            sample_pos = j / len(sample_images)

            # If the relative position has changed significantly (more than 20%)
            if abs(master_pos - sample_pos) > 0.2:
                moved_images.append(sample_img_id)

        # Identify missing images (in master but not in sample)
        for i, master_img in enumerate(master_images):
            if i not in master_to_sample:
                missing_images.append(master_img["id"])

        # Identify new images (in sample but not in master)
        for j, sample_img in enumerate(sample_images):
            if j not in sample_to_master:
                new_images.append(sample_img["id"])

        return missing_images, new_images, moved_images