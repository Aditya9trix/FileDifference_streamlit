import streamlit as st
from file_handler import FileHandler
from text_processor import TextProcessor
from image_processor import ImageProcessor
from table_processor import TableProcessor
from ui_components import UIComponents

def main():
    st.title("📄 File Comparison 🔍")
    st.write("Upload master and sample files to compare their content side by side")

    # File upload UI
    col1, col2 = st.columns(2)
    with col1:
        master_file = st.file_uploader("Upload Master File", type=["docx", "pdf", "txt"])
    with col2:
        sample_file = st.file_uploader("Upload Sample File", type=["docx", "pdf", "txt"])

    if master_file and sample_file:
        file_handler = FileHandler()
        image_processor = ImageProcessor()
        table_processor = TableProcessor()
        text_processor = TextProcessor()
        ui_components = UIComponents()

        # Extract and compare content
        master_content = file_handler.extract_content(master_file)
        sample_content = file_handler.extract_content(sample_file)

        # Compare content elements
        master_images = [item for item in master_content if item["type"] == "image"]
        sample_images = [item for item in sample_content if item["type"] == "image"]
        missing_images, new_images, moved_images = image_processor.compare_image_lists(
            master_images, sample_images
        )

        master_tables = [item for item in master_content if item["type"] == "table"]
        sample_tables = [item for item in sample_content if item["type"] == "table"]
        table_differences = table_processor.compare_tables(master_tables, sample_tables)

        master_texts = [item for item in master_content if item["type"] == "text"]
        sample_texts = [item for item in sample_content if item["type"] == "text"]
        text_differences = text_processor.compare_texts(master_texts, sample_texts)

        # Display complete file comparison
        st.subheader("📋 Complete File Comparison")
        col1, col2 = st.columns(2)
        with col1:
            ui_components.display_content(
                master_content,
                "Master File Content",
                table_differences=table_differences,
                text_differences=text_differences,
                missing_images=missing_images,
                is_master=True
            )
        with col2:
            ui_components.display_content(
                sample_content,
                "Sample File Content",
                table_differences=table_differences,
                text_differences=text_differences,
                new_images=new_images,
                moved_images=moved_images,
                is_master=False
            )

if __name__ == "__main__":
    main()