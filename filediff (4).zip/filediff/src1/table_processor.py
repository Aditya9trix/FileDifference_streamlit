import pandas as pd
from itertools import zip_longest

class TableProcessor:
    @staticmethod
    def highlight_differences(master_df, sample_df):
        """Highlight differences between master and sample tables"""
        max_rows = max(len(master_df), len(sample_df))
        max_cols = max(len(master_df.columns), len(sample_df.columns))

        master_df = master_df.reindex(range(max_rows)).reindex(columns=range(max_cols))
        sample_df = sample_df.reindex(range(max_rows)).reindex(columns=range(max_cols))

        def highlight_cells(val, master_val):
            if pd.isnull(val) and not pd.isnull(master_val):
                return 'background-color: red; color: white'  # Missing in sample
            elif not pd.isnull(val) and pd.isnull(master_val):
                return 'background-color: green; color: white'  # New in sample
            elif val != master_val:
                return 'background-color: orange; color: white'  # Changed
            return ''

        styled_sample = sample_df.style.apply(lambda row: [
            highlight_cells(row[col], master_df.iloc[row.name, col])
            for col in range(max_cols)
        ], axis=1)

        return styled_sample

    @staticmethod
    def compare_tables(master_tables, sample_tables):
        """Compare tables with highlighting"""
        differences = []
        for idx, (master_table, sample_table) in enumerate(zip_longest(master_tables, sample_tables, fillvalue=None)):
            if master_table is None:
                # Table exists only in sample file
                styled_sample = sample_table["content"].style.applymap(lambda x: 'background-color: #90EE90')
                differences.append({
                    "type": "new_in_sample",
                    "table": styled_sample,
                    "id": sample_table["id"],
                    "position": idx
                })
                continue

            if sample_table is None:
                # Table exists only in master file
                styled_master = master_table["content"].style.applymap(lambda x: 'background-color: #FFCCCB')
                differences.append({
                    "type": "missing_in_sample",
                    "table": styled_master,
                    "id": master_table["id"],
                    "position": idx
                })
                continue

            # Both tables exist, compare cell by cell with highlighting
            styled_sample = TableProcessor.highlight_differences(
                master_table["content"],
                sample_table["content"]
            )

            differences.append({
                "type": "difference",
                "master_table": master_table["content"],
                "sample_table": styled_sample,
                "master_id": master_table["id"],
                "sample_id": sample_table["id"],
                "position": idx
            })

        return differences