import difflib
from itertools import zip_longest

class TextProcessor:
    @staticmethod
    def word_level_diff(old_text, new_text):
        """Returns added and removed words between two sentences."""
        old_words = old_text.split()
        new_words = new_text.split()
        d = difflib.Differ()
        diff = list(d.compare(old_words, new_words))

        added_words = [word[2:] for word in diff if word.startswith("+ ")]
        removed_words = [word[2:] for word in diff if word.startswith("- ")]

        return added_words, removed_words

    @staticmethod
    def highlight_differences(master_text, sample_text):
        """Highlights differences with red for removed content in master and green for added content in sample"""
        if not master_text and not sample_text:
            return master_text, sample_text

        if not master_text:  # Entirely new text in sample
            return "", f"<span style='background-color: #90EE90;'>{sample_text}</span>"

        if not sample_text:  # Entirely missing text in sample
            return f"<span style='background-color: #FFCCCB;'>{master_text}</span>", ""

        # Use difflib to get the differences
        differ = difflib.Differ()
        diff = list(differ.compare(master_text.split(), sample_text.split()))

        master_output = []
        sample_output = []

        for word in diff:
            if word.startswith('- '):
                # Word removed from master (red in master)
                master_output.append(
                    f"<span style='background-color: #FFCCCB;'>{word[2:]}</span>")
            elif word.startswith('+ '):
                # Word added in sample (green in sample)
                sample_output.append(f"<span style='background-color: #90EE90;'>{word[2:]}</span>")
            elif word.startswith('  '):
                # Common word
                master_output.append(word[2:])
                sample_output.append(word[2:])

        # Join the words with spaces
        highlighted_master = ' '.join(master_output)
        highlighted_sample = ' '.join(sample_output)

        return highlighted_master, highlighted_sample

    @staticmethod
    def compare_texts(master_texts, sample_texts):
        """Compare text content between master and sample files."""
        differences = []
        for idx, (master_text, sample_text) in enumerate(zip_longest(master_texts, sample_texts, fillvalue=None)):
            if master_text is None:
                # Text exists only in sample file (new text)
                differences.append({
                    "type": "new_in_sample",
                    "content": f"<span style='background-color: #90EE90;'>{sample_text['content']}</span>",
                    "id": sample_text["id"],
                    "position": idx
                })
                continue

            if sample_text is None:
                # Text exists only in master file (missing text)
                differences.append({
                    "type": "missing_in_sample",
                    "content": f"<span style='background-color: #FFCCCB;'>{master_text['content']}</span>",
                    "id": master_text["id"],
                    "position": idx
                })
                continue

            # Both texts exist, compare them
            if master_text["content"] != sample_text["content"]:
                highlighted_master, highlighted_sample = TextProcessor.highlight_differences(
                    master_text["content"],
                    sample_text["content"]
                )
                differences.append({
                    "type": "difference",
                    "master_content": highlighted_master if highlighted_master else master_text["content"],
                    "sample_content": highlighted_sample if highlighted_sample else sample_text["content"],
                    "master_id": master_text["id"],
                    "sample_id": sample_text["id"],
                    "position": idx,
                    "has_changes": bool(highlighted_master) or bool(highlighted_sample)
                })
            else:
                differences.append({
                    "type": "identical",
                    "master_content": master_text["content"],
                    "sample_content": sample_text["content"],
                    "master_id": master_text["id"],
                    "sample_id": sample_text["id"],
                    "position": idx,
                    "has_changes": False
                })

        return differences