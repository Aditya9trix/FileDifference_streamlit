import streamlit as st
import matplotlib.pyplot as plt
import cv2

from image_processor import ImageProcessor


class UIComponents:
    @staticmethod
    def display_image_comparison(master_images, sample_images, missing_ids, new_ids, moved_ids):
        rows = max(len(master_images), len(sample_images))
        fig, axes = plt.subplots(rows, 2, figsize=(10, 5 * rows))

        if rows == 1:
            axes = [axes]

        for i in range(rows):
            # Master image column
            if i < len(master_images):
                border_color = (0, 0, 255) if master_images[i]["id"] in missing_ids else (255, 255, 255)
                axes[i][0].imshow(cv2.cvtColor(
                    ImageProcessor.add_border(master_images[i]["content"], border_color),
                    cv2.COLOR_BGR2RGB))
                axes[i][0].set_title(f"Master Image {i + 1}")
            else:
                axes[i][0].axis('off')

            # Sample image column
            if i < len(sample_images):
                if sample_images[i]["id"] in new_ids:
                    border_color = (0, 255, 0)  # Green for new images
                elif sample_images[i]["id"] in moved_ids:
                    border_color = (0, 255, 255)  # Yellow for moved images
                else:
                    border_color = (255, 255, 255)  # White for unchanged images

                axes[i][1].imshow(cv2.cvtColor(
                    ImageProcessor.add_border(sample_images[i]["content"], border_color),
                    cv2.COLOR_BGR2RGB))
                axes[i][1].set_title(f"Sample Image {i + 1}")
            else:
                axes[i][1].axis('off')

        for ax in axes:
            for a in ax:
                a.axis('off')

        plt.tight_layout()
        st.pyplot(fig)

    @staticmethod
    def display_content(file_content, title, table_differences=None, text_differences=None,
                       missing_images=None, new_images=None, moved_images=None, is_master=False):
        st.subheader(title)
        table_counter = 0
        text_counter = 0

        for item in file_content:
            if item["type"] == "text":
                if text_differences:
                    current_diff = None
                    for diff in text_differences:
                        if (is_master and "master_id" in diff and diff["master_id"] == item["id"]) or \
                                (not is_master and "sample_id" in diff and diff["sample_id"] == item["id"]):
                            current_diff = diff
                            break
                        elif (is_master and diff.get("type") == "missing_in_sample" and diff.get(
                                "position") == text_counter) or \
                                (not is_master and diff.get("type") == "new_in_sample" and diff.get(
                                    "position") == text_counter):
                            current_diff = diff
                            break

                    if current_diff:
                        if is_master:
                            # Master file display
                            if current_diff["type"] == "missing_in_sample":
                                st.warning("❌ This text is missing in the sample file")
                                st.markdown(
                                    f"<div style='background-color: #FFCCCB; padding: 10px; border-radius: 5px;'>{item['content']}</div>",
                                    unsafe_allow_html=True)
                            elif current_diff["type"] == "difference":
                                # st.write("Changes (red=removed in sample):")
                                st.markdown(current_diff["master_content"], unsafe_allow_html=True)
                            else:
                                st.write(item["content"])
                        else:
                            # Sample file display
                            if current_diff["type"] == "new_in_sample":
                                st.success("✅ This text is new in the sample file")
                                st.markdown(
                                    f"<div style='background-color: #90EE90; padding: 10px; border-radius: 5px;'>{item['content']}</div>",
                                    unsafe_allow_html=True)
                            elif current_diff["type"] == "difference":
                                # st.write("Changes (green=added in sample):")
                                st.markdown(current_diff["sample_content"], unsafe_allow_html=True)
                            else:
                                st.write(item["content"])
                    else:
                        st.write(item["content"])
                text_counter += 1

            elif item["type"] == "table":
                if table_differences:
                    current_diff = None
                    for diff in table_differences:
                        if (is_master and "master_id" in diff and diff["master_id"] == item["id"]) or \
                                (not is_master and "sample_id" in diff and diff["sample_id"] == item["id"]):
                            current_diff = diff
                            break
                        # Also check for missing tables by position
                        elif (is_master and "missing_in_sample" in diff["type"] and diff["id"] == item["id"]) or \
                                (not is_master and "new_in_sample" in diff["type"] and diff["id"] == item["id"]):
                            current_diff = diff
                            break

                    if current_diff:
                        if current_diff["type"] == "missing_in_sample" and is_master:
                            # st.warning("❌ Table missing in sample file")
                            styled_table = item["content"].style.applymap(lambda x: 'background-color: #FFCCCB')
                            st.dataframe(styled_table)
                        elif current_diff["type"] == "new_in_sample" and not is_master:
                            st.success("✅ New table in sample file")
                            styled_table = item["content"].style.applymap(lambda x: 'background-color: #90EE90')
                            st.dataframe(styled_table)
                        elif current_diff["type"] == "difference":
                            if is_master:
                                # st.write("Master Table:")
                                st.dataframe(current_diff["master_table"])
                            else:
                                # st.write("Sample Table (green=new, red=missing, orange=changed):")
                                st.dataframe(current_diff["sample_table"])
                    else:
                        st.dataframe(item["content"])
                else:
                    st.dataframe(item["content"])
                table_counter += 1
            elif item["type"] == "image":
                if missing_images and item["id"] in missing_images:
                    bordered_image = ImageProcessor.add_border(item["content"], (0, 0, 255))
                    st.image(cv2.cvtColor(bordered_image, cv2.COLOR_BGR2RGB),
                             caption=f"Missing in Sample File (ID: {item['id']})")
                elif new_images and item["id"] in new_images:
                    bordered_image = ImageProcessor.add_border(item["content"], (0, 255, 0))
                    st.image(cv2.cvtColor(bordered_image, cv2.COLOR_BGR2RGB),
                             caption=f"New in Sample File (ID: {item['id']})")
                elif moved_images and item["id"] in moved_images:
                    bordered_image = ImageProcessor.add_border(item["content"], (0, 255, 255))
                    st.image(cv2.cvtColor(bordered_image, cv2.COLOR_BGR2RGB),
                             caption=f"Position changed (ID: {item['id']})")
                else:
                    st.image(cv2.cvtColor(item["content"], cv2.COLOR_BGR2RGB),
                             caption=f"Image (ID: {item['id']})")

    @staticmethod
    def display_table_comparison(master_tables, sample_tables, table_differences):
        """Display detailed table comparison view"""
        st.subheader("📌 Detailed Table Comparison")

        for diff in table_differences:
            st.write(f"### Table {diff['position'] + 1}")
            col1, col2 = st.columns(2)

            with col1:
                if diff["type"] == "missing_in_sample":
                    # st.warning("❌ Missing in sample file")
                    st.dataframe(diff["table"])
                elif diff["type"] == "difference":
                    st.write("**Master Table**")
                    st.dataframe(diff["master_table"])

            with col2:
                if diff["type"] == "new_in_sample":
                    st.success("✅ New in sample file")
                    st.dataframe(diff["table"])
                elif diff["type"] == "difference":
                    st.write("**Sample Table**")
                    st.dataframe(diff["sample_table"])

    @staticmethod
    def display_text_comparison(master_texts, sample_texts, text_differences):
        """Display detailed text comparison view"""
        st.subheader("📌 Detailed Text Comparison")

        for diff in text_differences:
            st.write(f"### Text Block {diff['position'] + 1}")
            col1, col2 = st.columns(2)

            with col1:
                if diff["type"] == "missing_in_sample":
                    st.warning("❌ Missing in sample file")
                    st.markdown(f"<div style='background-color: #FFCCCB; padding: 10px;'>{diff['content']}</div>",
                               unsafe_allow_html=True)
                elif diff["type"] == "difference":
                    st.write("**Master Text**")
                    st.write(diff["master_content"])

            with col2:
                if diff["type"] == "new_in_sample":
                    st.success("✅ New in sample file")
                    st.markdown(f"<div style='background-color: #90EE90; padding: 10px;'>{diff['content']}</div>",
                               unsafe_allow_html=True)
                elif diff["type"] == "difference":
                    st.write("**Sample Text**")
                    st.markdown(diff["sample_content"], unsafe_allow_html=True)